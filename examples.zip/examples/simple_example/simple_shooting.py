import numpy as np
from scipy.linalg import norm 
from matplotlib import pyplot as plt 

def dynamics(xp):
    x1, x2 = xp[0], xp[1]
    p1, p2 = xp[2], xp[3]
    DXP = np.array([-p1 - 5.0*np.sin(x2), 1.0, -x1 + 10.0, 5.0*np.cos(x2)*p1])
    return DXP 
pass

def dynamics_with_cost(xp, time):
    xp = xp[0:2]
    DXP = np.zeros([1,3])
    DXP[0,0:2] = dynamics(xp, time)
    DXP[0,2] = ((xp[0]-10)**2 + xp[1]**2)/2.0
    return DXP
pass 

def var_dynamics(flow, xp):
    x1, x2 = xp[0], xp[1]
    p1, p2 = xp[2], xp[3]
    DF = np.zeros(flow.shape)
    DF[0,1] = -5.0*np.cos(x2)
    DF[0,2] = -1.0
    DF[2,0] = -1.0
    DF[3,1] = -5.0*np.sin(x2)*p1
    DF[3,2] = 5.0*np.cos(x2)
    return DF@flow
pass 

def RK4_solver(XP0, h, n, times):
    XP   = XP0
    flow = np.eye(len(XP0))
    for k in range(1, len(times)):
        k1   = dynamics(XP)
        k2   = dynamics(XP + h*k1/2)
        k3   = dynamics(XP + h*k2/2)
        k4   = dynamics(XP + h*k3)
        XP   = XP + h*(k1 + 2*(k2 + k3) + k4)/6

        K1    = var_dynamics(flow)
        K2    = var_dynamics(flow + h*k1/2)
        K3    = var_dynamics(flow + h*k2/2)
        K4    = var_dynamics(flow + h*k3)
        flow += h*(K1 + 2*(K2 + K3) + K4)/6
    return XP, flow 
pass 

def euler_solver(XP0, h, n, times):
    XP   = XP0
    flow = np.eye(len(XP0))
    for k in range(1, len(times)):
        flow = flow + h*var_dynamics(flow, XP)
        XP   = XP + h*dynamics(XP)
    return XP, flow 
pass

def shooting_function(XPT):
    return np.array([XPT[2], XPT[3]])
pass 

def Shooting_Solver(p0, eps, h, n, times):
    # p0 is the inicial guess
    # the state has fix inicial condition x(0) = 5
    # eps is the error allowed for the numerical approximation

    Shot = 2*eps
    max_iter = 0
    while norm(Shot) > eps and max_iter < 101:
        XP0         = np.array([5.0, 0.0, p0[0], p0[1]])
        XPT, flow_T = euler_solver(XP0, h, n, times) 
        Shot = shooting_function(XPT)
        # The shooting function is only Shot = p(T), for the only parameter p0
        # The derivative of the Shooting function is only dp(T)/dp(0)
        DevShot = flow_T[2:4,2:4]
        A       = DevShot.T@DevShot
        b       = -DevShot.T@Shot
        delta   = np.copy(np.linalg.solve(A, b))
        p0      += delta
        max_iter += 1
    pass 
    return p0
pass


def solution(p0):
    T = 12
    # Time discretization:
    h     = 0.0001
    times = np.linspace(0,T, 1000)
    n  = len(times)
    XP = np.zeros([3,n])
    XP[:,0] = np.array([5.0, p0, 0.0])
    for k in range(1,len(times)):
        time = times[k-1]
        k1   = dynamics_with_cost(XP[:,k-1], time)
        k2   = dynamics_with_cost(XP[:,k-1] + h*k1[0,:]/2, time + h/2)
        k3   = dynamics_with_cost(XP[:,k-1] + h*k2[0,:]/2, time + h/2)
        k4   = dynamics_with_cost(XP[:,k-1] + h*k3[0,:], time + h)
        XP[:,k] = XP[:,k-1] + h*(k1[0,:] + 2*(k2[0,:] + k3[0,:]) + k4[0,:])/6
    pass 
    return XP
pass 

T = 12
#Time discretization:
h     = 0.0001
times = np.linspace(0,T, 1000)
n     = len(times) 

ini_condition = Shooting_Solver(np.array([-7.05, 18.6]), 1e-10, h, n, times)

print('P0', ini_condition)

XP = solution(ini_condition)


plt.figure()
plt.subplot(311)
plt.title('States Trajectories')
plt.plot(times,  XP[0,:], label = '$x$')
plt.subplot(312)
plt.plot(times,  XP[2,:], label = '$x$')
plt.subplot(313)
plt.plot(times,  XP[1,:], label = '$p$')
plt.plot(times, -XP[1,:], label = 'p')
plt.legend()
plt.show()