import numpy as np 
import symengine as sp
from symengine_function import gradient, lie_bracket, xp_bracket
from sympy.parsing.sympy_parser import parse_expr
from scipy.integrate import solve_ivp
from matplotlib import pyplot as plt

#from BocopUtils import readSolFile
from shooting_ver1_09 import shooting

states_list         = 'n s i'
lin_cont_list       = 'v'
nonlin_cont_list    = 't'
arcs_list           = ['bang_plus', 'sing', 'bang_minus']
cost_function_list  = '0.0'
running_cost_list   = 'i + 50.0*v + 1000.0*t**2'


affine_dynamics_list  = ['0.0', '-s', '0.0']

drift_dynamics_list   = ['4e-5*n*(1.0 - n/5000.0) - 0.01*i - 0.5e-5*n', 
                         '4e-5*n*(1.0 - n/5000.0) - 0.5*i*s/n + 0.01*(n-s-i) - 0.5e-5*s', 
                         '0.5*i*s/n - (0.1 + 0.1 + t)*i - 0.5e-5*i']


shooting_algorithm = shooting(states_list, arcs_list, lin_cont_list, nonlin_cont_list = nonlin_cont_list,
                              running_cost = running_cost_list, time_horizon = [0.0, 100.0])

# Add drift and affine dynamics
shooting_algorithm.add_drift_dynamics(drift_dynamics_list)
shooting_algorithm.add_lin_dynamics(affine_dynamics_list, bounds = [0.0, 0.25])

# Add final constraints
shooting_algorithm.add_constrainst_IF(cost_function_str   = cost_function_list, 
                                      constraints_IF_list = None)

control_subs_dict = {'t' : 'i*p_i/(2000.0)'}
shooting_algorithm.singular_control_symbolic(control_subs_dict)

shooting_algorithm.sym_to_numpy()
"""
# Estimates for parameters: 
#B1 = 1, B2 = 50, B3 = 1000, K = 5000, delta = 0.1, beta = 0.5, 
# gamma = 0.1, omega = 0.01, alpha = 4e-5, mu = 0.5e-5, T_f = 100.0
# BOCOP steps = 500
shooting_args = y = np.array([4864.5, 420.0, 24.0, 2450.0,
                              4851., 1305.0, 0.5, 2638.0,
                              -0.207, 0.255, 2.99,
                              -0.0103, 0.12, 6.09,
                              -0.0103, 0.0384, 42.9, 
                              10., 44.7]).reshape(19,1)

"""
# Estimates for parameters: 
#B1 = 1, B2 = 50, B3 = 1000, K = 5000, delta = 0.1, beta = 0.5, 
# gamma = 0.1, omega = 0.01, alpha = 4e-5, mu = 4e-5, T_f = 100.0
# BOCOP steps = 200
shooting_args = y = np.array([4865.2, 420.0, 25.9, 2440.0,
                              4851.2, 1290.0, 0.5, 2638.0,
                              -0.178, 0.238, 3.12,
                              -0.0101, 0.118, 6.1,
                              -0.0101, 0.038, 44., 
                              9., 44.2]).reshape(19,1)

#shooting_args += 0.1*np.random.randn(19,1)


initial_conditions = np.array([5000.0, 4500.0, 499.0, 0.0]).reshape(4,1)


initial_conditions, shot_final = shooting_algorithm.solve_shooting(shooting_args, initial_conditions, tol = 1e-11, integration_method = 'Radau')

print(initial_conditions, '\n\n', shot_final)

times, controls, states, costates, switching_function, switching_function_dt = shooting_algorithm.optimal_trajectory(initial_conditions, control_bounds = [0.0, 0.25])

#######################
# Read BOCOP solution
#######################

objective, time_steps, time_stages, state, control, parameters, costate, boundary_mult, status = readSolFile('prob.sol')
# since the method used was Gauss-2, 2 stage method, 
# the controls double resolution than the states and costates
control = (control[:,::2] + control[:,1::2])/2

SF_Bocop    = []
SF_Bocop_dt = []

xp_all_BOCOP = np.append(state[:,0:-1], costate[0:3,:], axis = 0)
SF_Bocop = shooting_algorithm.switching_function_np(xp_all_BOCOP.T)
SF_Bocop_dt = shooting_algorithm.switching_function_dt_np(xp_all_BOCOP.T)

############################################
# Plotting optimal trajectories
############################################

N = states[:,0]
S = states[:,1]
I = states[:,2]
R = N - S - I 

S_normalized = S/N
I_normalized = I/N
R_normalized = R/N

plt.style.use('seaborn')
from matplotlib import rc
#rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})
## for Palatino and other serif fonts use:
rc('font',**{'family':'serif','serif':['Palatino']})
rc('text', usetex=True)

marker_style = dict(color = 'tab:red', linestyle = '--', marker = 'o',
                    markersize = 7, markerfacecoloralt = 'tab:green')

params = {'legend.fontsize': 13,
          'legend.handlelength': 2}
plt.rcParams.update(params)

plt.figure()
plt.subplot(221)
plt.plot(times, N, label = 'total population')
#plt.plot(times, 100*S_normalized, label = 'percentage of susceptible')
#plt.plot(times, 100*I_normalized, label = 'percentage of infected')
#plt.plot(times, 100*R_normalized, label = 'percentage of recovered')
plt.legend()
plt.subplot(222)
plt.plot(times, S, label = 'susceptible population')
plt.plot(times, I, label = 'infected population')
plt.plot(times, R, label = 'recovered population')
plt.plot(times, states[:,3], label = 'cost')
plt.legend()

plt.subplot(223)
plt.plot(times, costates[:,0], label = '$p_N$')
plt.plot(times, costates[:,1], label = '$p_S$')
plt.legend()

plt.subplot(224)
plt.plot(times, costates[:,2], label = '$p_I$')
plt.legend()
plt.show()

final_time = 100.0
plt.figure()
plt.subplot(121)
plt.title('Vaccination')
plt.plot(final_time*time_steps[0:-1] ,control[0,:], 'ro--', markersize = 6, label = 'BOCOP solution')
plt.plot(times , controls ,label = 'Shooting solution')
plt.plot(times, switching_function/200.0, 'g--',label = '$H_v$')
#plt.plot(times, switching_function_dt/200.0, '--y',label = '$H_v$')
plt.ylim((-0.1, 0.26))
plt.legend()

plt.subplot(122)
plt.title('Treatment')
plt.plot(final_time*time_steps[0:-1] ,control[1,:], 'ro--', markersize = 5, label = 'BOCOP solution')
plt.plot(times , I*costates[:,2]/2000.0 ,label = 'Shooting solution')
plt.legend()
plt.show()

"""
plt.figure()
plt.plot(times, switching_function/5000.0, label = '$H_v$')
plt.plot(times, switching_function_dt/5000.0, label = '$\dot{H}_v$')
plt.plot(final_time*time_steps[0:-1], SF_Bocop/5000.0, label = '$H_v$-BOCOP')
plt.plot(final_time*time_steps[0:-1], SF_Bocop_dt/5000.0, label = '$\dot{H}_v$-BOCOP')
plt.title("Switching function: $H_v$")
plt.legend()
plt.show()
"""