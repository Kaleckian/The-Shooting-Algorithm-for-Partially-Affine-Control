import numpy as np 
import symengine as sp
from matplotlib import pyplot as plt
import seaborn as sns 
from symengine_function import gradient, lie_bracket, xp_bracket
from sympy.parsing.sympy_parser import parse_expr
from shooting_ver1_09 import shooting
#from BocopUtils import readSolFile


states_list         = 'x1 x2'
nonlin_cont_list    = 'u'
running_cost_list   = '0.5*((x1-10.0)**2 + u**2) '

# Define dynamics strings
drift_dynamics_list = ['u -5.0*sin(x2)', '1']


# Constructor for the shooting algorithm class
shooting_algorithm = shooting(states_list, arcs_list=None, lin_cont_list= None, nonlin_cont_list= nonlin_cont_list, running_cost= running_cost_list, time_horizon = [0.0, 12.0])

# Add drift and affine dynamics
shooting_algorithm.add_drift_dynamics(drift_dynamics_list)
shooting_algorithm.add_constrainst_IF(cost_function_str   = None,
                                      constraints_IF_list = None)

# Compute Singular Linear Control
control_subs_dict = {'u' : '-p_x1'}
shooting_algorithm.f0 = shooting_algorithm.f0.subs(control_subs_dict)

#shooting_algorithm.singular_control_symbolic(control_subs_dict)

shooting_algorithm.sym_to_numpy()
shooting_args = np.array([1.0, 1.0]).reshape(2,1)
#shooting_args = np.ones([15,1])
#shooting_args += 0.05*np.random.randn(15,1)
initial_conditions = np.array([5.0, 0.0, 0.0]).reshape(3,1)
    
initial_conditions, shot = shooting_algorithm.solve_shooting(shooting_args, initial_conditions, tol = 1e-10, integration_method = 'RK45')

print('Optimal initial conditions: \n', initial_conditions)
print('Shooting function evaluated at optimal initial conditions: \n', shot)

states, costates, times = shooting_algorithm.optimal_trajectory(initial_conditions, control_bounds = None)



#######################
# Read BOCOP solution
#######################

""" objective, time_steps, time_stages, state, control, parameters, costate, boundary_mult, status = readSolFile('prob.sol')
# since the method used was Gauss-2, 2 stage method, 
# the controls double resolution than the states and costates
control = (control[:,::2] + control[:,1::2])/2

SF_Bocop    = []
SF_Bocop_dt = []

xp_all_BOCOP = np.append(state[:,0:-1], costate[0:2,:], axis = 0)
SF_Bocop = shooting_algorithm.switching_function_np(xp_all_BOCOP.T)
SF_Bocop_dt = shooting_algorithm.switching_function_dt_np(xp_all_BOCOP.T)
 """
############################################
# Plotting optimal trajectories
############################################
"""
x_1 = states[:,0]
x_2 = states[:,1]
x_3 = states[:,2]
"""
plt.style.use('seaborn')
from matplotlib import rc
#rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})
## for Palatino and other serif fonts use:
rc('font',**{'family':'serif','serif':['Palatino']})
#rc('text', usetex=True)

marker_style = dict(color = 'tab:red', linestyle = '--', marker = 'o',
                    markersize = 7, markerfacecoloralt = 'tab:green')

params = {'legend.fontsize': 14,
          'legend.handlelength': 2}
plt.rcParams.update(params)

'''
plt.figure()
plt.subplot(311)
plt.plot(times, states[:,0], label = '$x$')
plt.plot(times, -costates[:,0], label = '$u$')
plt.legend()
plt.subplot(312)
plt.plot(times, costates[:,0], label = '$p$')
plt.plot(times, costates[:,1], label = '$p_1$')
plt.legend()
plt.subplot(313)
plt.plot(times, states[:,2], label = 'running cost')
plt.legend()
plt.show()
'''

plt.figure()
plt.subplot(121)
plt.plot(times, states[:,0], label = '$x$')
plt.plot(times, -costates[:,0], label = '$u$')
plt.legend()
plt.subplot(122)
plt.plot(times, costates[:,0], label = '$p$')
plt.plot(times, costates[:,1], label = '$p_1$')
plt.legend()
plt.show()


