import numpy as np 
import symengine as sp
from symengine_function import gradient, lie_bracket, xp_bracket
from sympy.parsing.sympy_parser import parse_expr
from scipy.integrate import solve_ivp
from matplotlib import pyplot as plt

# ver 1_08 is the working version
from shooting_ver1_09 import shooting
#from shooting_ver1_09 import shooting

states_list         = 'n1 n2'
lin_cont_list       = 'v'
arcs_list           = ['bang_plus', 'bang_minus']
cost_function_list  = '3.0*(n1_f + n2_f)'
running_cost_list   = '0.1*n1 + 0.1*n2 + 0.5*v'

# Define dynamics strings
drift_dynamics_list  = ['-0.197*n1 + 2*(0.356)*n2', '0.197*n1 - 0.356*n2']
affine_dynamics_list = ['-2*(0.356)*n2', '0.0']

# Constructor for the shooting algorithm class
shooting_algorithm = shooting(states_list, arcs_list, lin_cont_list, 
                              nonlin_cont_list = None, running_cost = running_cost_list, time_horizon = [0.0,21.0])

# Add drift and affine dynamics
shooting_algorithm.add_drift_dynamics(drift_dynamics_list)
shooting_algorithm.add_lin_dynamics(affine_dynamics_list, bounds= [0.0, 0.9])

# Compute Singular Linear Control
shooting_algorithm.sing_cont_lin_only()

# Assemble initial-final lagrangian
shooting_algorithm.add_constrainst_IF(cost_function_list)
F  = shooting_algorithm.dynamics_symbolic()
SF = shooting_algorithm.symbolic_shooting_function()


#print('Singular linear control:\n', shooting_algorithm.delta_sing)
print('Shooting function:\n', SF)
#print('Hamiltonian:\n', shooting_algorithm.Hamiltonian)
#print('State dynamics:\n', shooting_algorithm.f0 + shooting_algorithm.f1*shooting_algorithm.delta_sing )
#print('Costate dynamics:\n', shooting_algorithm.dp.subs({shooting_algorithm.lin_cont[0]: shooting_algorithm.delta_sing}))
#print('Dynamics:\n', F)
#print('xp_f:\n', shooting_algorithm.xp_f)
#print('xp_i:\n', shooting_algorithm.xp_i)

# Generate numpy functions from sympy/symengine symbolic expressions
shooting_algorithm.sym_to_numpy()

# Estimates for initial conditions
shooting_args = np.array([0.0876, 0.08,  5.638,  4.15, 1.5813, 8.6, 13.19, 10.0]).reshape(8,1)
#shooting_args = np.array([0.2139, -0.215,  0.0914,  0.5422, 1.0322, 0.2112, 1.00, 1.115]).reshape(8,1)
#shooting_args += np.random.randn(8,1)
initial_conditions = np.array([0.2988, 0.7012, 0.0]).reshape(3,1)

initial_conditions, shot_final = shooting_algorithm.solve_shooting(shooting_args, initial_conditions, tol = 1e-13, integration_method = 'Radau')

print(initial_conditions, '\n\n', shot_final)

times, controls, states, costates, switching_function, switching_function_dt = shooting_algorithm.optimal_trajectory(initial_conditions, [0.0, 0.9])


############################################
# Plotting optimal trajectories
############################################


plt.style.use('seaborn')
from matplotlib import rc
rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})
## for Palatino and other serif fonts use:
rc('font',**{'family':'serif','serif':['Palatino']})
#rc('text', usetex=True)

plt.figure()
plt.subplot(211)
for k in range(2):
    #subplot_str = '31'+str(k)
    #plt.subplot(subplot_str)
    plt.plot(times, states[:,k], label = '$N_'+str(k+1)+'$')
#plt.plot(times, states[:,2], label = 'running cost')
plt.title('Optimal states trajectory')
plt.legend()

plt.subplot(223)
plt.title('Optimal Treatment Strategy')
plt.plot(times, controls, label = '$u$')
plt.legend()

plt.subplot(224)
plt.title('Running Cost')
plt.plot(times, states[:,2], label = 'running cost')
plt.legend()
plt.show()

'''
plt.figure()
plt.subplot(221)
for k in range(2):
    #subplot_str = '31'+str(k)
    #plt.subplot(subplot_str)
    plt.plot(times, states[:,k], label = '$N_'+str(k+1)+'$')
#plt.plot(times, states[:,2], label = 'running cost')
plt.title('Optimal states trajectory')
plt.legend()
#plt.show()

plt.subplot(222)
for k in range(2):
    plt.plot(times, costates[:,k], label = '$p_'+str(k+1)+'$')
plt.title('Costates trajectory')
plt.legend()
#plt.show()

plt.subplot(223)
plt.title('Optimal Treatment Strategy')
plt.plot(times, controls)
#plt.show()
plt.subplot(224)
plt.plot(times, switching_function, label = '$H_v$')
plt.plot(times, switching_function_dt, label = '$\dot{H}_v$')
plt.title("Switching function: $H_v$")
plt.legend()
plt.show()
'''