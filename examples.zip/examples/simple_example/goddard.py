import numpy as np 
import symengine as sp
from symengine_function import gradient, lie_bracket, xp_bracket
from sympy.parsing.sympy_parser import parse_expr
from scipy.integrate import solve_ivp
from matplotlib import pyplot as plt


from shooting_ver1_09 import shooting

states_list         = 'r v m'
lin_cont_list       = 'delta'
arcs_list           = ['bang_plus', 'sing', 'bang_minus']
constraints_IF_list = ['r_f - 0.01']
cost_function_list  = '-m_f'

D   = '310.0*v**2*exp(-500.0*(r))'
affine_dynamics_list  = ['0.0', '3.5' ,'-7.0']
drift_dynamics_list = ['v', '-1/(r+1.0)**2 + 310.0*v**2*exp(-500.0*(r))/m', '0.0']

shooting_algorithm = shooting(states_list, arcs_list, lin_cont_list, nonlin_cont_list = None,
                              running_cost = None, time_horizon = [0.0, 0.173])

# Add drift and affine dynamics
shooting_algorithm.add_drift_dynamics(drift_dynamics_list)
shooting_algorithm.add_lin_dynamics(affine_dynamics_list, bounds= [0.0, 1.0])

# Add final constraints
shooting_algorithm.add_constrainst_IF(cost_function_str   = cost_function_list, 
                                      constraints_IF_list = constraints_IF_list)
# Compute Singular Linear Control
shooting_algorithm.sing_cont_lin_only()
#print(shooting_algorithm.dp)
#print(shooting_algorithm.delta_sing)
shooting_algorithm.sym_to_numpy()

#SF = shooting_algorithm.symbolic_shooting_function()
#print(SF)
SF_fast = shooting_algorithm.symbolic_shooting_function_fast()
#print(SF_fast)


# Estimates for initial conditions
shooting_args = np.array([0.0006, 0.0567, 0.8408, 0.004, 0.114, 0.6341, -49.8, -1.8885, -0.6970, 
                          -44.9, -1.3919, -0.8284, -19.6, -1.2925, -1.0189, 0.0222, 0.068, -13.6981]).reshape(18,1)
#shooting_args = np.array([1.0005, 0.05, 0.8541, 1.0045, 0.114, 0.6343, -51.16, -1.8622, -0.705, 
#                          -45.9, -1.3971, -0.83, -19.0388, -1.2891, -1.0183, 0.0208,0.06747, -13.81]).reshape(18,1)
#shooting_args += np.random.randn(18,1)
initial_conditions = np.array([0.0, 0.0, 1.0]).reshape(3,1)

SF = shooting_algorithm.symbolic_shooting_function_fast()

#print(shooting_algorithm.Hamiltonian)


initial_conditions, shot_final = shooting_algorithm.solve_shooting_test(shooting_args, initial_conditions, tol = 1e-5, integration_method = 'Radau')

print(initial_conditions, '\n\n', shot_final)



"""
############################
# Compute optimal trajectory
#
# and plot solution
############################

times, controls, states, costates, switching_function, switching_function_dt = shooting_algorithm.optimal_trajectory(initial_conditions, [-1,1])


plt.figure()
for k in range(3):
    plt.plot(times, states[k,:])
plt.show()

plt.figure()
for k in range(3):
    plt.plot(times, costates[k,:])
plt.show()

plt.figure()
plt.plot(times, controls)
plt.show()

plt.figure()
plt.plot(times, switching_function)
plt.show()

plt.figure()
plt.plot(times, switching_function_dt)
plt.show()
"""