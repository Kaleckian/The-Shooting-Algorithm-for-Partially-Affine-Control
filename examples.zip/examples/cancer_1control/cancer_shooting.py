import numpy as np 
import symengine as sp
from matplotlib import pyplot as plt
import seaborn as sns 
from symengine_function import gradient, lie_bracket, xp_bracket
from sympy.parsing.sympy_parser import parse_expr
from shooting_ver1_09 import shooting
from BocopUtils import readSolFile

#########################################################
# Read BOCOP solution and Obtain Bang-Singular Structure
#########################################################

objective, time_steps, time_stages, state, control, parameters, costate, boundary_mult, status = readSolFile('prob.sol')
# since the method used was Gauss-2, 2 stage method, 
# the controls double resolution than the states and costates
#control = (control[:,::2] + control[:,1::2])/2

SF_Bocop    = []
SF_Bocop_dt = []

xp_all_BOCOP = np.append(state[:,0:-1], costate[0:2,:], axis = 0)
#SF_Bocop = shooting_algorithm.switching_function_np(xp_all_BOCOP.T)
#SF_Bocop_dt = shooting_algorithm.switching_function_dt_np(xp_all_BOCOP.T)

Switching_Times         = []
Switching_Times_indexes = []
arcs                    = []

final_time = 60.0
times = final_time*time_steps[0:-1]


control_bounds = [0.0, 0.9]
if control[0,0] == control_bounds[0]:
    arcs.append('bang_minus')
if control[0,0] == control_bounds[1]:
    arcs.append('bang_plus')
if control[0,0] != control_bounds[0] and control[0,0] != control_bounds[1]:
    arcs.append('sing')

for k in range( times.shape[0]):
    # First we check current arc
    if control[0,k] == control_bounds[0]:
        arc = 'bang_minus'
    elif control[0,k] == control_bounds[1]:
        arc = 'bang_plus'
    elif control[0,k+1] != control_bounds[0] and control[0,k+1] != control_bounds[1]:
        arc = 'sing'
    
    # If the arc type has changed, we append a new arc
    if arc != arcs[-1]:
        arcs.append(arc)
        Switching_Times.append(times[k-1])
        Switching_Times_indexes.append(k-1)
    pass
pass 
print(arcs)
length = state[:, Switching_Times_indexes].shape[0]*state[:, Switching_Times_indexes].shape[1]
states_estimates = state[:, Switching_Times_indexes].T.reshape(length,)

length_costates  = costate[0:2, Switching_Times_indexes].shape[0]*costate[0:2, Switching_Times_indexes].shape[1]
print(length_costates, length)
costates_initial = costate[0:2,0].reshape(2,)
costates_estimates = costate[0:2, Switching_Times_indexes].T.reshape(length_costates,)

print(Switching_Times)
print(states_estimates)
shooting_args = np.append(states_estimates, costates_initial, axis = 0)
shooting_args = np.append(shooting_args, costates_estimates, axis = 0)
shooting_args = np.append(shooting_args, Switching_Times, axis = 0)
shooting_args = shooting_args.reshape(shooting_args.shape[0],1)
#shooting_args = states_estimates.append(costates_initial).append(costates_estimates).append(Switching_Times)
print(shooting_args)

#########################################################
# Set up Shooting Algorithm
#########################################################

states_list         = 'n1 n2'
lin_cont_list       = 'v'
arcs_list           = arcs 
cost_function_list  = '3.0*(n1_f + n2_f)'
running_cost_list   = '0.1*n1 + 0.1*n2 + 0.5*v'

# Define dynamics strings
drift_dynamics_list  = ['-0.197*n1 + 2*(0.356)*n2', '0.197*n1 - 0.356*n2']
affine_dynamics_list = ['-2*(0.356)*n2', '0.0']

# Constructor for the shooting algorithm class
shooting_algorithm = shooting(states_list, arcs_list, lin_cont_list, 
                              nonlin_cont_list = None, running_cost = running_cost_list, time_horizon = [0.0,final_time])

# Add drift and affine dynamics
shooting_algorithm.add_drift_dynamics(drift_dynamics_list)
shooting_algorithm.add_lin_dynamics(affine_dynamics_list, bounds= [0.0, 0.9])

# Compute Singular Linear Control
shooting_algorithm.sing_cont_lin_only()

# Assemble initial-final lagrangian
shooting_algorithm.add_constrainst_IF(cost_function_list)
#F  = shooting_algorithm.dynamics_symbolic()
#SF = shooting_algorithm.symbolic_shooting_function()


#print('Singular linear control:\n', shooting_algorithm.delta_sing)
#print('Shooting function:\n', SF)
#print('Hamiltonian:\n', shooting_algorithm.Hamiltonian)
#print('State dynamics:\n', shooting_algorithm.f0 + shooting_algorithm.f1*shooting_algorithm.delta_sing )
#print('Costate dynamics:\n', shooting_algorithm.dp.subs({shooting_algorithm.lin_cont[0]: shooting_algorithm.delta_sing}))
#print('Dynamics:\n', F)
#print('xp_f:\n', shooting_algorithm.xp_f)
#print('xp_i:\n', shooting_algorithm.xp_i)

# Generate numpy functions from sympy/symengine symbolic expressions
shooting_algorithm.sym_to_numpy()

# Estimates for initial conditions
#shooting_args = np.array([0.0008, 0.0007,  21.5,  4.65, 1.654, 992.0, 1528.0, 46.4]).reshape(8,1)
initial_conditions = np.array([0.2988, 0.7012, 0.0]).reshape(3,1)

initial_conditions, shot_final = shooting_algorithm.solve_shooting(shooting_args, initial_conditions, tol = 1e-13, integration_method = 'Radau')

print(initial_conditions, '\n\n', shot_final)

times, controls, states, costates, switching_function, switching_function_dt = shooting_algorithm.optimal_trajectory(initial_conditions, control_bounds = [0.0, 0.9])



############################################
# Plotting optimal trajectories
############################################

x_1 = states[:,0]
x_2 = states[:,1]
x_3 = states[:,2]

plt.style.use('seaborn')
from matplotlib import rc
#rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})
## for Palatino and other serif fonts use:
rc('font',**{'family':'serif','serif':['Palatino']})
rc('text', usetex=True)

marker_style = dict(color = 'tab:red', linestyle = '--', marker = 'o',
                    markersize = 7, markerfacecoloralt = 'tab:green')

params = {'legend.fontsize': 14,
          'legend.handlelength': 2}
plt.rcParams.update(params)


plt.figure()
plt.subplot(221)
plt.title('States Trajectories')
plt.plot(times, states[:,0], label = '$x_1$')
plt.plot(times, states[:,1], label = '$x_2$')
#plt.plot(times, states[:,2], label = 'running cost')
plt.legend()

plt.subplot(222)
plt.title('Costates Trajectories')
plt.plot(times, costates[:,0], label = '$p_1$')
plt.plot(times, costates[:,1], label = '$p_2$')
plt.legend()

plt.subplot(223)
plt.title('Linear Control')
plt.plot(final_time*time_steps[0:-1] ,control[0,:], 'ro--', markersize = 6, label = 'BOCOP solution')
plt.plot(times , controls ,label = 'Shooting solution')
plt.plot(times, switching_function, 'g--',label = '$H_v$')
#plt.plot(times, switching_function_dt/200.0, '--y',label = '$H_v$')
plt.ylim((-0.05, 1.0))
plt.legend()

plt.show()
