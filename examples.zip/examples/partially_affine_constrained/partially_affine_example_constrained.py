import numpy as np 
import symengine as sp
from matplotlib import pyplot as plt
import seaborn as sns 
from symengine_function import gradient, lie_bracket, xp_bracket
from sympy.parsing.sympy_parser import parse_expr
from shooting_ver1_09 import shooting
from BocopUtils import readSolFile


states_list         = 'x1 x2'
lin_cont_list       = 'v'
nonlin_cont_list    = 'u'
arcs_list           = ['bang_plus','sing','bang_minus']
cost_function_list  = '-2*x2_f'
running_cost_list   = 'x1**2 + x2**2 + u**2 + 10.0*x2*v'
if_constraints_list = ['x1_f - 1.0']

# Define dynamics strings
drift_dynamics_list = ['x2 + u', '0.0']
affine_dynamics_list = ['0.0', '1.0']

# Constructor for the shooting algorithm class
shooting_algorithm = shooting(states_list, arcs_list, lin_cont_list, nonlin_cont_list, running_cost_list, time_horizon = [0.0, 2.0])

# Add drift and affine dynamics
shooting_algorithm.add_drift_dynamics(drift_dynamics_list)
shooting_algorithm.add_lin_dynamics(affine_dynamics_list, bounds = [0.0, 0.5])

# Compute Singular Linear Control
control_subs_dict = {'u' : '-0.5*p_x1'}
shooting_algorithm.singular_control_symbolic(control_subs_dict)
shooting_algorithm.add_constrainst_IF(cost_function_str   = cost_function_list,
                                      constraints_IF_list = if_constraints_list)

shooting_algorithm.sym_to_numpy()
shooting_args = np.array([0.0397, 0.118, 0.074, 0.3, 0.245, 0.3743, -0.2345, -0.0468, -0.2362, -1.19, -0.48, -2.4568, 0.2, 0.9, -1.654]).reshape(15,1)
#shooting_args = np.ones([15,1])
shooting_args += 0.05*np.random.randn(15,1)
initial_conditions = np.array([0.0, 0.0, 0.0]).reshape(3,1)
    
initial_conditions, shot = shooting_algorithm.solve_shooting(shooting_args, initial_conditions, tol = 1e-14, integration_method = 'RK45')

print('Optimal initial conditions: \n', initial_conditions)
print('Shooting function evaluated at optimal initial conditions: \n', shot)

times, controls, states, costates, switching_function, switching_function_dt = shooting_algorithm.optimal_trajectory(initial_conditions, control_bounds = [0.0, 0.5])



#######################
# Read BOCOP solution
#######################

objective, time_steps, time_stages, state, control, parameters, costate, boundary_mult, status = readSolFile('prob.sol')
# since the method used was Gauss-2, 2 stage method, 
# the controls double resolution than the states and costates
control = (control[:,::2] + control[:,1::2])/2

SF_Bocop    = []
SF_Bocop_dt = []

xp_all_BOCOP = np.append(state[:,0:-1], costate[0:2,:], axis = 0)
SF_Bocop = shooting_algorithm.switching_function_np(xp_all_BOCOP.T)
SF_Bocop_dt = shooting_algorithm.switching_function_dt_np(xp_all_BOCOP.T)

############################################
# Plotting optimal trajectories
############################################

x_1 = states[:,0]
x_2 = states[:,1]
x_3 = states[:,2]

plt.style.use('seaborn')
from matplotlib import rc
#rc('font',**{'family':'sans-serif','sans-serif':['Helvetica']})
## for Palatino and other serif fonts use:
rc('font',**{'family':'serif','serif':['Palatino']})
rc('text', usetex=True)

marker_style = dict(color = 'tab:red', linestyle = '--', marker = 'o',
                    markersize = 7, markerfacecoloralt = 'tab:green')

params = {'legend.fontsize': 14,
          'legend.handlelength': 2}
plt.rcParams.update(params)

plt.figure()
plt.subplot(121)
plt.plot(times, states[:,0], label = '$x_1$')
plt.plot(times, states[:,1], label = '$x_2$')
plt.plot(times, states[:,2], label = 'running cost')
plt.legend()

plt.subplot(122)
plt.plot(times, costates[:,0], label = '$p_1$')
plt.plot(times, costates[:,1], label = '$p_2$')
plt.legend()

plt.show()

final_time = 2.0
plt.figure()
plt.subplot(121)
plt.title('Linear Control')
plt.plot(final_time*time_steps[0:-1] ,control[0,:], 'ro--', markersize = 6, label = 'BOCOP solution')
plt.plot(times , controls ,label = 'Shooting solution')
plt.plot(times, switching_function, 'g--',label = '$H_v$')
#plt.plot(times, switching_function_dt/200.0, '--y',label = '$H_v$')
plt.ylim((-0.05, 0.55))
plt.legend()

plt.subplot(122)
plt.title('Non Linear Control')
plt.plot(final_time*time_steps[0:-1] ,control[1,:], 'ro--', markersize = 5, label = 'BOCOP solution')
plt.plot(times , -costates[:,0]/2.0 ,label = 'Shooting solution')
plt.legend()
plt.show()


plt.figure()
plt.subplot(221)
plt.title('States Trajectories')
plt.plot(times, states[:,0], label = '$x_1$')
plt.plot(times, states[:,1], label = '$x_2$')
plt.plot(times, states[:,2], label = 'running cost')
plt.legend()

plt.subplot(222)
plt.title('Costates Trajectories')
plt.plot(times, costates[:,0], label = '$p_1$')
plt.plot(times, costates[:,1], label = '$p_2$')
plt.legend()

plt.subplot(223)
plt.title('Linear Control')
plt.plot(final_time*time_steps[0:-1] ,control[0,:], 'ro--', markersize = 6, label = 'BOCOP solution')
plt.plot(times , controls ,label = 'Shooting solution')
plt.plot(times, switching_function, 'g--',label = '$H_v$')
#plt.plot(times, switching_function_dt/200.0, '--y',label = '$H_v$')
plt.ylim((-0.05, 0.55))
plt.legend()

plt.subplot(224)
plt.title('Non Linear Control')
plt.plot(final_time*time_steps[0:-1] ,control[1,:], 'ro--', markersize = 5, label = 'BOCOP solution')
plt.plot(times , -costates[:,0]/2.0 ,label = 'Shooting solution')
plt.legend()
plt.show()

